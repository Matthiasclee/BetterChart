require "sinatra"
get("/") do
	erb :home
end
get("/chart") do
	@start = params["yearStart"] + "-" + params["monthStart"] + "-" + params["dayStart"]
	@end = params["yearEnd"] + "-" + params["monthEnd"] + "-" + params["dayEnd"]
	erb :chart
end